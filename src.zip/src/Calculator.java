import java.util.List;

public class Calculator {

    public Calculator() {

    }

    public double calculate(Double quantity, Double cost) {
        return quantity * cost;
    }

    public double calculateMode1(PhotoInputSection inputSection) {
        return 0.0;
    }

//    public double calculateMode2(List<PhotoInputSection> inputSections) {
//        double total = 0.00;
//
//    }

}
